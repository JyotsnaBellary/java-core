public class DomainValidationJUnit {
	//fill the code
	public void createBoInstance() {
		//fill the code
	}
	public void testValidDomain() {
		//fill the code
	}
	public void testInvalidDomain() {
		//fill the code
	}
}

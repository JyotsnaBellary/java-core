public class VISACard {
	
	public Double computeRewardPoints(String type, Double amount){
		
        //fill code here

        return .01 + amount;
    }

}

class HPVISACard extends VISACard{
    public Double computeRewardPoints(String type, Double amount){
			
        //fill code here

        Double r = super().computeRewardPoints(String type, Double amount);
         return r + 10;
    }
}

public class Exhibition {
 
    //Fill your code here

    Double calculateAmount() {

        //Fill your code here

        return 0.0;
    }
     	
}
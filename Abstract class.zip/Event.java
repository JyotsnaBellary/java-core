public class Event {

    //Fill your code here

}
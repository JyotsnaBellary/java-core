import java.util.*;
class Main {
    public static void main(String[] args) {
        
            // Fill your code here
            System.out.println(args[0] + " - Command Line Arguments");
        
     }
}
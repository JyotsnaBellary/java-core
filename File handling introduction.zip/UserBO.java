import java.io.*;
import java.util.*;

public class UserBO{
    List<User> list=new ArrayList<User>();
    
    public List<User>readFromFile(BufferedReader br) throws IOException
    {
        //Fill your code here
        return list;
    }
    public void display(List<User> list)
    {
        //Fill your code here
    }
}
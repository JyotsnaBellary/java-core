public class BillHeader {
	// fill your code here
	Date 	issueDate;
	Date 	dueDate;
	Double	originalAmount;
	Double	amountOutstanding ;

	
}
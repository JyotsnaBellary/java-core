public class OddEvenJUnit {
	public void createBoInstance() {
		//fill the code
	}
	public void testOddNumber() {
		//fill the code
	}
	public void testEvenNumber() {
		//fill the code
	}
}

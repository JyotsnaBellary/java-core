public class UserDAO {
	public List<User> getAllUsers(){
		List<User> userList = new ArrayList<User>();
		//your code goes here...
		return userList;
	}
}

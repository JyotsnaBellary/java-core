drop table if exists user;
create table user(userId varchar(255) primary key,name varchar(255),password varchar(255),phoneNumber bigint(20));

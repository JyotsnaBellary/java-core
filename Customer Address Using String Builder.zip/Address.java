// fill your code here

public class Address {
	private String line1;
	private String line2;
	private String city;
	private String country;
	private int zipCode;
	
	// fill your code here
}
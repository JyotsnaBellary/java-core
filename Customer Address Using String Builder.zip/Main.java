
public class Main {
    public static void main(String[] args) throws IOException {
		// fill your code here
	}
}

public class Article{
	//Your code here
	String line;
	Integer count;
	
}

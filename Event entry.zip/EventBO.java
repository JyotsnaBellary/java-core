public class EventBO {
	//Your code here
}

public class TicketBooking{

	//Fill your code
}

public class Main{
    public static void main(String[] args){    	     
           //Fill your code
           int count = 0;
           System.out.println("Arguments :");
           for(int i=0;i<args.length;i++)  {
           System.out.println(args[i]);
           }
           System.out.println("The number of arguments is " + args.length);
    }
}
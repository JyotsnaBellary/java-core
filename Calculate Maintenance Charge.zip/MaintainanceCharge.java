interface MaintainanceCharge
{
    //Fill your code here
}
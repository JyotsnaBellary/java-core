class CurrentAccount
{
    //Fill your code here
}
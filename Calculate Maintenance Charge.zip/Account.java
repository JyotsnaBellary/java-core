class Account
{
    private String name;
    private String accountNumber;
    private double balance;

    //Fill your code here
}
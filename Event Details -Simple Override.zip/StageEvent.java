class StageEvent extends Event{
       //Fill your code here
    }

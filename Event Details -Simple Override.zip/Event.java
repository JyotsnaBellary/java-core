class Event{
    
    
     //Your code here


}
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class FactorialJUnit {
	//Fill the code
	public void createBoInstance() {
		//Fill the code
	}
	
	public void testFactorial() {
		//Fill the code
	}
	
}

public class Main {
	public static void main(String[] args)  {
		//your code goes here...
	}
}
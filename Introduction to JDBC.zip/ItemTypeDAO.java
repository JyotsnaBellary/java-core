import java.util.*;
public class ItemTypeDAO {
	public List<ItemType> getAllItemTypes() {
		List<ItemType> itemTypeList = new ArrayList<>();
		//your code goes here...
		return itemTypeList;
	}
}

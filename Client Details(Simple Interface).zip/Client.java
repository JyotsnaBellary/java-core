public class Client {
	//Fill your code
}

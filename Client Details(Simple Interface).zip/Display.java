//create interface
interface Display{
    void displayClientDetails();
}
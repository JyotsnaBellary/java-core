public class Donor {


   //fill your code

}


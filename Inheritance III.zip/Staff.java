public class Staff {
    // fill your code
}

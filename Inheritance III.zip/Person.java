
public class Person{

        //    Fill your code
        string	name
Date	dateOfBirth
string	gender
string	mobileNumber
string	bloodBankName
       
    }



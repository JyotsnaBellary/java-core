public class ICICI{

    //Fill your code

}
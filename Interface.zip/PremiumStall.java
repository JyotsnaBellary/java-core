public class PremiumStall{
	//fill your code here
}

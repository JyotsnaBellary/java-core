public class ExecutiveStall{
	//fill your code here
}

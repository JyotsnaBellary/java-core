public class GoldStall{
	//fill your code here
}


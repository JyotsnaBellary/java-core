class StageEvent extends Event{

    //Fill your code here

    public Double totalCost() {

       //Fill your code here
        
        return 0.00;
    }
    
    public String toString() {
       //Fill your code here
    }
}
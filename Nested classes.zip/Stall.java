public class Stall {
        //fill your code here
        
	
}
public class Villain 
{
    //fill your code
}
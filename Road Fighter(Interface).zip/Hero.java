public class Hero 
{
    // fill your code
    
}
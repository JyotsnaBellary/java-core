public GameStatus
{
//fill your code
}
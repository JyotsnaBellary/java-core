public class Main {
	public static void main(String args[]) {
		//write your code here
		System.out.format("%-5s %-5s %-15s %-10s %s\n","Id","Name","Contact Detail","Username","Password");
        UserDAO userDAO = new UserDAO();
		List<User> userList = userDAO.getAllUsers();
        for(User user : userList) {
            System.out.format("%-5s %-5s %-15s %-10s %s\n", user.getId(), user.getName(), user.getContactDetail(), user.getUsername(), user.getPassword());
        }
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter the username to be deleted:");
        String username = bufferedReader.readLine();
        if(deleteUser(username)){
            System.out.println("User deleted successfully");
        } else{
            System.out.println("User not found");
        }
        List<User> userList = userDAO.getAllUsers();
        for(User user : userList) {
            System.out.format("%-5s %-5s %-15s %-10s %s\n", user.getId(), user.getName(), user.getContactDetail(), user.getUsername(), user.getPassword());
        }
	}
}

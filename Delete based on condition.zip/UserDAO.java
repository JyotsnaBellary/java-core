import java.util.*;
public class UserDAO {
	public List<User> getAllUser() {
		List<User> userList =new ArrayList<>();
		//write your code here
        try {
            Connection connection = DBConnection.getConnection();
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM \"user\"");
             while(resultSet.next()) {
                 userList.add(new User(resultSet.getLong(1),  resultSet.getString(2), resultSet.getString(3), resultSet.getString(4),  resultSet.getString(5)));
//                 System.out.format("%-5s %-15s %-10s %s\n", id, name, deposit, costPerDay);
             }
        }
        catch(SQLException e) {
            e.printStackTrace();

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
		return userList;
	}
	
	public Boolean deleteUser(String username) {
		//write your code here
		return false;
	}
}

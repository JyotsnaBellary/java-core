

public class Aircraft {

    //fill your code 
	
}


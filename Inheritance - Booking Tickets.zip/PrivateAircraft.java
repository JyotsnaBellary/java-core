public class PrivateAircraft{
    
		//fill your code 			
					
}

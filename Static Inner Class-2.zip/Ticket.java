public class Ticket {
    //fill your code here
		
}

public class ItemTypeBO {
    
	public void add(ItemType n1,ItemType[] itemTypeArray,Integer index){
		//Your code here
	}
    
	public void search(String search,ItemType[] itemTypeArray){
		//Your code here
	}
	public void display(ItemType[] itemTypeArray){
		//Your code here
	}
}

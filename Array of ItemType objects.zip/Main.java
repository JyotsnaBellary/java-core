
import java.io.*;

import java.util.*;

class Main{ 

    public static void main(String[] args) throws Exception{

        Scanner sc=new Scanner(System.in);

        int n;

        double cpd,d;

        System.out.print("Enter the Number of Item Type"); 

        n=sc.nextInt(); 

        ArrayList<ItemType> items = new ArrayList<ItemType>();

        for(int i=1;i<=n;i++){

            System.out.print("Enter the Item Type"+ i+" "Name);

            String name = sc.next();

            System.out.println("Enter the cost per day");

            Double cpd=sc.nextDouble(); 

            System.out.println("Enter the deposit");

            Double d=sc.nextDouble();

            ItemType it = new ItemType(name,cpd,d);

            items.add(it);  

            System.out.println("New item added successfully");  

        }
        System.out.println("Enter the Name of the item to be searched")
    }
}
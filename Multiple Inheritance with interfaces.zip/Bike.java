public class Bike

{

		
        
    //Fill your code

	


}
	

	
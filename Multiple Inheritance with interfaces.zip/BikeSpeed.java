public BikeSpeed{

	


    //Fill your code



}


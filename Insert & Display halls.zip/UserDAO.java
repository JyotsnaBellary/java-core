public class UserDAO {
	public User getUser(String username) {
		User user = null;
		//write your code here
		return user;
	}
}

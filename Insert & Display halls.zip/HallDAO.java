import java.util.ArrayList;
import java.util.List;
public class HallDAO {
	public void saveHall(Hall hall) {
		//write your code here
	}
	
	public List<Hall> getAllHall() {
		List<Hall> hallList = new ArrayList<Hall>();
        //write your code here
        return hallList;
	}
}

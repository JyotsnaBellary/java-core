public class Shape {

        //fill your code here

	public static class Rectangle {
	    //fill your code here
	}
	
	public static class Triangle {
	    //fill your code here
	}	
}
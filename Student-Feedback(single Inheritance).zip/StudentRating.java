class StudentRating{

              //Fill your code

	
}

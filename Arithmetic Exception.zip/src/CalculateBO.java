public class CalculateBO {
	public double calculateCost(Integer cost, Integer days) throws ArithmeticException {
		return (cost/days);
	}
}
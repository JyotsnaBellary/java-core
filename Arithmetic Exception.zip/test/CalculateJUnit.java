public class CalculateJUnit {
	public void createBoInstance() {
		//fill the code
	}
	public void testCalculateCost() {
		//fill the code
	}
	public void testCalculateCostException() {
		//fill the code
	}
}

// fill your code here

public class Customer {
	
	// fill your code here
}
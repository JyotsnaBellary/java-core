

public class UserBO {
	public staticvoidvalidate(User u){
		//Your code here
	}
}

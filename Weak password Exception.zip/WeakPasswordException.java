
public class WeakPasswordException{
		//Your code here
	
}

class Main {
    
    public static void main(String[] args) {
    	System.out.println("Enter the ratings");
        //Fill your code here
    }
}
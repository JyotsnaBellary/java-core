class MovieRating {
    String ratings;
    
    public MovieRating() { }
    
    public MovieRating(String ratings) {
        this.ratings = ratings;
    }
    
    public void run() {
        //Fill your code here
    }
}
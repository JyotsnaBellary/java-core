public class User {
	//write your code here
}

public class CityCount {
	//write your code here
}

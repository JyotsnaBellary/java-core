
class Exhibition {
      
          //Your code here
}
class StageEvent {
        String name;
        String detail;
    	String ownerName;
      
          //your code here
}
public class Square{
	//write your code here
}

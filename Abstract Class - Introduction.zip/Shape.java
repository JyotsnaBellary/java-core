public class Shape {
	//write your code here
}

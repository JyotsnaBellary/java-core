public class Rectangle {
	//write your code here
}

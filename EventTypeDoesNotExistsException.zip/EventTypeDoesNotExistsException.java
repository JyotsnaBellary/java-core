class EventTypeDoesNotExistsException {
		//fill your code here
}

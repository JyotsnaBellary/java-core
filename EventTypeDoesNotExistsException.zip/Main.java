import java.util.ArrayList;

public class Main {
	public static void main(String args[]) {
		
		ArrayList<EventType> typeList=new ArrayList<>();
		typeList.add(new EventType("Stage Event",new Long(1)));
		typeList.add(new EventType("Exhibition",new Long(2)));
		typeList.add(new EventType("Sports meet",new Long(3)));
		
		//write your code here
	}
	
	public static Boolean isValid(Long typeId, List<EventType> typeList) throws EventTypeDoesNotExistsException {
        //write your code here
    }
}
